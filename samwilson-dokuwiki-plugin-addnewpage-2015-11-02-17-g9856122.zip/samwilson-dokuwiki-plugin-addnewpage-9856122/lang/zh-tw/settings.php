<?php
/*USE : UTF8*/

/*
 *  Traditional Chinese file
 */
$lang['addpage_exclude']  = "排除哪些命名空間(namespace), 使用 ; 來區分多個命名空間(namespace)";
$lang['addpage_showroot'] = "顯示最上層(Root)命名空間(namespace)";
$lang['addpage_hide']     = "使用 {{NEWPAGE>[ns]}} 語法時不要顯示出命名空間(namespace)的選項, 沒有打勾就會列出指定命名空間(namespace)底下所有的子命名空間(subnamespace)項目";
$lang['addpage_hideACL']  = "沒有打勾 : 表示當使用者沒有新增頁面權限時就顯示沒有權限的訊息而不會顯示出新增頁面的輸入欄.";
