<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hugo Smet <hugo.smet@scarlet.be>
 */
$lang['addpage_exclude']       = 'Uitgesloten naamruimte\'s (gescheiden door ;)';
$lang['addpage_showroot']      = 'Toon root naamruimte';
$lang['addpage_hide']          = 'Bij gebruik van {{NEWPAGE>[ns]}} syntax: Verberg naamruimte selectie (niet aangevinkt: toon enkel sub naamruimte\'s)';
$lang['addpage_hideACL']       = 'Verberg {{NEWPAGE}} wanneer de gebruiker geen rechten heeft om pagina\'s toe te voegen (toon melding wanneer niet aangevinkt)';
