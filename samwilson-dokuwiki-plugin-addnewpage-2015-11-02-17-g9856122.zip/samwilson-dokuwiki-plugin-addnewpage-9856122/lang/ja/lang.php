<?php
/*
Japanese language file
 */
$lang['namespaceRoot'] = "ルート";
$lang['okbutton']      = "ページ追加";
$lang['nooption']      = "ページの追加が許可されていません";
//Setup VIM: ex: et ts=2 enc=utf-8 :
