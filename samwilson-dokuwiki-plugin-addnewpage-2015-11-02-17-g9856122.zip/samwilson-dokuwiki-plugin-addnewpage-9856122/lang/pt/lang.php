<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alfredo Silva <alfredo.silva@sky.com>
 */
$lang['namespaceRoot']         = 'Raiz';
$lang['okbutton']              = 'Adicionar página';
$lang['nooption']              = 'Não está autorizado para adicionar páginas';
