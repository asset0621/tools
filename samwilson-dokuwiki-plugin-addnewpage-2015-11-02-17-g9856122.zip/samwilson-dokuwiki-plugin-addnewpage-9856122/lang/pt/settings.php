<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alfredo Silva <alfredo.silva@sky.com>
 */
$lang['addpage_exclude']       = 'Espaços do nome excluídos (separados com ;)';
$lang['addpage_showroot']      = 'Mostrar espaço do nome da raiz';
$lang['addpage_hide']          = 'Quando utiliza a sintaxe {{NEWPAGE>[ns]}} : Ocultar a seleção do espaço do nome (desmarcado : mostrar apenas sub-espaço do nome)';
$lang['addpage_hideACL']       = 'Ocultar  {{NEWPAGE}} se o utilizador não possuir permissões para adicionar páginas (mostrar mensagem se desmarcado).';
