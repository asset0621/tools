<?php
/*USE : UTF8*/

/*
 * Polish language file
 */
$lang['addpage_exclude']  = "Wykluczone nazwy (oddzielone średnikiem)";
$lang['addpage_showroot'] = "Pokaż nazwę głównego katalogu";
$lang['addpage_hide']     = "Kiedy używasz składni {{NEWPAGE>[nazwa]}}: Ukryj nazwę grupy (niezaznaczone: pokaż tylko podnazwy)";
$lang['addpage_hideACL']  = "Ukryj {{NEWPAGE}} jeżeli użytkownicy nie posiadają uprawnień dodawania nowych stron (pokaż komunikat jeśli niezaznaczone)";
