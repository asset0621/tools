<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Ali Almlfy <Almlfy@hotmail.com>
 */
$lang['namespaceRoot']         = 'الجذر';
$lang['okbutton']              = 'أضف صفحة';
$lang['nooption']              = 'لا يسمح لك إضافة صفحات';
