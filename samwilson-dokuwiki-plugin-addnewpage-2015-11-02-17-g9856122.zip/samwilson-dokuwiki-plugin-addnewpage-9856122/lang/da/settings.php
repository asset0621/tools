<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Soren Birk <soer9648@eucl.dk>
 */
$lang['addpage_exclude']       = 'Ekskluderet navnerum (separeret med ;)';
$lang['addpage_showroot']      = 'Vis rod-navnerum';
$lang['addpage_hide']          = 'Når du benytter {{NEWPAGE>[ns]}} syntaks: Skjul valgte navnerum (umarkeret: vis kun under-navnerum)';
$lang['addpage_hideACL']       = 'Skjul {{NEWPAGE}} hvis brugeren ikke har rettigheder til at tilføje sider (vis meddelelse hvis umarkeret)';
