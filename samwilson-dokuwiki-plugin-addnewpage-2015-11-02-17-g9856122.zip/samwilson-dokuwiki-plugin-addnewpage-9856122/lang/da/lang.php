<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Soren Birk <soer9648@eucl.dk>
 */
$lang['namespaceRoot']         = 'Rod';
$lang['okbutton']              = 'Tilføj side';
$lang['nooption']              = 'Du har ikke tilladelse til at tilføje sider';
