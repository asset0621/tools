<?php
/*USE : UTF8*/

/*
 * Spanish language file
 */
$lang['addpage_exclude']  = "excluir directorio(namespace) separados por punto y coma (;)";
$lang['addpage_showroot'] = "Mostrar directorio(namespace) raiz";
$lang['addpage_hide']     = "cuando se usa la sintaxis {{NEWPAGE>[dir]}}: se oculta el selector de directorio (desmarcado: muestra solo sub-directorios (sub-namespaces))";
$lang['addpage_hideACL']  = "si esta desmarcado, muesta un mensaje de error de privilegios. Si el usuario no tiene permiso de crear una pagina, simplemente se oculta el codigo {{NEWPAGE}}";
