<?php
/*USE : UTF8*/

/*
 * French language file
 */
$lang['addpage_exclude']  = "namespaces &agrave; exclure (s&eacute;par&eacute;s par un ;)";
$lang['addpage_showroot'] = "Afficher le namespace racine";
$lang['addpage_hide']     = "Quand vous utlisez la syntaxe {{NEWPAGE>[ns]}} : Cache la selection de namespace (décoché: affiche uniquement les sous-namespaces)";
$lang['addpage_hideACL']  = "Si non cochée, affiche un message lorsque l'utlisateur n'a pas les droits d'ajout de page. Sinon, cache simplement {{NEWPAGE}}";
