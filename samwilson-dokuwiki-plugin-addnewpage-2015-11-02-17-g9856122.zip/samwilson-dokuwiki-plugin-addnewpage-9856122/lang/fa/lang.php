<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Sam01 <m.sajad079@gmail.com>
 */
$lang['namespaceRoot']         = 'ریشه';
$lang['okbutton']              = 'اضافه‌کردن صفحه';
$lang['nooption']              = 'شما امکان اضافه کردن صفحه‌ها را ندارید';
