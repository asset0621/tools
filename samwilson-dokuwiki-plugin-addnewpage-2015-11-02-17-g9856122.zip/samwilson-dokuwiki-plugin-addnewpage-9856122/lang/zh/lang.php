<?php
/*
 * Chinese(Simplified) language file
 */
$lang['namespaceRoot']="根部命名空间";
$lang['okbutton']     ="增加页面";
$lang['nooption']     ="抱歉，您没有权限增加页面";
//Setup VIM: ex: et ts=2 enc=utf-8 :
