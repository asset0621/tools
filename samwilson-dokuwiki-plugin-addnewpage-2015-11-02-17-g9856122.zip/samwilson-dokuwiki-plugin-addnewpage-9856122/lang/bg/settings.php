<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Neli Dimitrova <neli.dimitrova.office@gmail.com>
 */
$lang['addpage_exclude']       = 'Списък с изключени именни пространства (разделени със знак ;)';
$lang['addpage_showroot']      = 'Покажи основното именно пространство';
$lang['addpage_hide']          = 'Когато се използва синтаксиса {{NEWPAGE>[ns]}}: Скрий избора на именно пространство (ако не е избрано: покажи само дъщерните именни пространства)';
$lang['addpage_hideACL']       = 'Скрий {{NEWPAGE}}, ако потребителят няма права да добавя страници (покажи съобщение, ако не е избрано)';
