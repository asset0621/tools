<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Neli Dimitrova <neli.dimitrova.office@gmail.com>
 */
$lang['namespaceRoot']         = 'Основно именно пространство';
$lang['okbutton']              = 'Добави страница';
$lang['nooption']              = 'Нямате право да създавате страница тук';
