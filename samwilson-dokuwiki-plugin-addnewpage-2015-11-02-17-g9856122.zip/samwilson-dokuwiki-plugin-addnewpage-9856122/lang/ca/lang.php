<?php
/*USE : UTF8*/
/*
 * Catalan language file
 */
$lang['namespaceRoot'] = "Arrel";
$lang['okbutton']      = "Crear";
$lang['nooption']      = "No teniu permisos suficients per afegir una p&agrave;gina";
