<?php
$meta['addpage_exclude']  = array('string');
$meta['addpage_showroot'] = array('onoff');
$meta['addpage_hide']     = array('onoff');
$meta['addpage_hideACL']  = array('onoff');
